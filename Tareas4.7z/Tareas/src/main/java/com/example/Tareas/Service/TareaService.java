package com.example.Tareas.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.Tareas.Model.Tareas;
import com.example.Tareas.repository.TareaRepository;

@Service

public class TareaService {

    @Autowired
    private TareaRepository tareaRepository;

   
    public List<Tareas> obtenerTodasLasTareas() {
        return tareaRepository.findAll();
    }

    
    public Optional<Tareas> obtenerTareaPorId(Long idTarea) {
        return tareaRepository.findById(idTarea);
    }


     public List<Tareas> obtenerTareasPorEvento(Long idEvento) {
        return tareaRepository.findByIdEvento(idEvento);
    }

    public Tareas crearTarea(Tareas tareas) {
        return tareaRepository.save(tareas);
    }

    // Actualizar tarea existente
    public Optional<Tareas> actualizarTarea(Long idTarea, Tareas tareaActualizada) {
        return tareaRepository.findById(idTarea).map(tarea -> {
            tarea.setDescripcion(tareaActualizada.getDescripcion());
            tarea.setFechaInicio(tareaActualizada.getFechaInicio());
            tarea.setFechaFin(tareaActualizada.getFechaFin());
            tarea.setFechaModificacion(tareaActualizada.getFechaModificacion());
            tarea.setIdEvento(tareaActualizada.getIdEvento());
            return tareaRepository.save(tarea);
        });
    }

    public void eliminarTarea(Long idTarea) {
        tareaRepository.deleteById(idTarea);
    }


}
