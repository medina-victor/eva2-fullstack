package com.example.Tareas.Controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Tareas.Model.Tareas;
import com.example.Tareas.Service.TareaService;
import com.example.Tareas.repository.TareaRepository;

@RestController
@RequestMapping("api/v1/Tareas")
public class TareasController {

    @Autowired
    TareaService tareaService;

    @Autowired
    TareaRepository tareaRepository;



    @GetMapping 
    public ResponseEntity<List<Tareas>> getTodasLasTareas() {
        List<Tareas> tareas = tareaService.obtenerTodasLasTareas();
        return ResponseEntity.ok(tareas);
}

 // Obtener tarea por ID
    @GetMapping("/{id}")
    public ResponseEntity<Tareas> getTareaPorId(@PathVariable Long id) {
        Optional<Tareas> tareaOpt = tareaService.obtenerTareaPorId(id);
        return tareaOpt.map(ResponseEntity::ok)
                       .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Obtener tareas por Evento
    @GetMapping("/evento/{idEvento}")
    public ResponseEntity<List<Tareas>> getTareasPorEvento(@PathVariable Long idEvento) {
        List<Tareas> tareas = tareaService.obtenerTareasPorEvento(idEvento);
        return ResponseEntity.ok(tareas);
    }

    // Crear nueva tarea
    @PostMapping
    public ResponseEntity<Tareas> crearTarea(@RequestBody Tareas tarea) {
        Tareas tareaCreada = tareaService.crearTarea(tarea);
        return new ResponseEntity<>(tareaCreada, HttpStatus.CREATED);
    }

    // Actualizar tarea por ID
    @PutMapping("/{id}")
    public ResponseEntity<Tareas> actualizarTarea(@PathVariable Long id, @RequestBody Tareas tareaActualizada) {
        Optional<Tareas> tareaOpt = tareaService.actualizarTarea(id, tareaActualizada);
        return tareaOpt.map(tarea -> ResponseEntity.ok(tarea))
                       .orElseGet(() -> ResponseEntity.notFound().build());
    }

    // Eliminar tarea por ID
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarTarea(@PathVariable Long id) {
        tareaService.eliminarTarea(id);
        return ResponseEntity.noContent().build();
    }


}