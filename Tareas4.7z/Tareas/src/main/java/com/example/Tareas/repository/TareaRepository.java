package com.example.Tareas.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Tareas.Model.Tareas;

public interface TareaRepository  extends JpaRepository<Tareas,Long>{
    List<Tareas> findByIdEvento(Long idEvento);

}
