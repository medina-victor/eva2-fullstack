package com.example.soporte.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.soporte.model.Soporte;
import com.example.soporte.repository.SoporteRepository;
import com.example.soporte.webuser.Usuariosuser;

import jakarta.transaction.Transactional;

@Service
@Transactional

public class SoporteService {
    @Autowired
    private SoporteRepository soporteRepository;

    @Autowired
    private Usuariosuser usuariouser;

    
    public Soporte guardarSoporte(Soporte soporte) {
        return soporteRepository.save(soporte);
    }

    public List<Soporte> listaSoporte(){
        return soporteRepository.findAll();
    }



    
   

}


