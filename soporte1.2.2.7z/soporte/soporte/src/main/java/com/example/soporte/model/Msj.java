package com.example.soporte.model;

public class Msj {

}
