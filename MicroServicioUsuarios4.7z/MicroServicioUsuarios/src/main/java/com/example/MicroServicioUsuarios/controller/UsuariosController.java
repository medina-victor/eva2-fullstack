package com.example.MicroServicioUsuarios.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import com.example.MicroServicioUsuarios.model.Usuarios;
import com.example.MicroServicioUsuarios.repository.UsuariosRepository;
import com.example.MicroServicioUsuarios.service.UsuariosService;

@RestController
@RequestMapping("/api/v1/Usuarios")

public class UsuariosController {

    @Autowired
    private UsuariosService usuariosService;

    
    public UsuariosController(UsuariosRepository usuariosRepository) {
    }

   @PostMapping("/validar")
    public ResponseEntity<?> validar(@RequestBody Usuarios usuario) {
    return usuariosService.validarCredenciales(usuario.getCorreo(), usuario.getClave())
            .map(ResponseEntity::ok)
            .orElseThrow(() -> new ResponseStatusException(
                    HttpStatus.UNAUTHORIZED, "NO autorizado: datos no validos"));
    }



    @GetMapping
    public ResponseEntity<List<Usuarios>> listar() {
        List<Usuarios> usuarios = usuariosService.listarUsuarios();
        if (usuarios.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(usuarios);
    }

   @PostMapping
    public ResponseEntity<?> guardarUsuarios(@RequestBody Usuarios usuarios) {
    try {
        Usuarios usu = usuariosService.saveUsuario(usuarios);
        return ResponseEntity.status(HttpStatus.CREATED).body(usu);
    } catch (Exception e) {
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
            .body("Error al guardar usuario: " + e.getMessage());
    }
}

    @GetMapping("/{id}")
    public ResponseEntity<Usuarios> buscarUsuariosPorId(@PathVariable Integer id) {
        try {
            Usuarios usu = usuariosService.buscarUsuariosporId(id);
            return ResponseEntity.ok(usu);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> borrarUsuariosPorId(@PathVariable Integer id){
        try {
            Usuarios usu = usuariosService.buscarUsuariosporId(id.intValue());
            usuariosService.borrarUsuarios(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }



    @PutMapping("/{id}")
    public ResponseEntity<Usuarios> actualizarUsuariosPorid(@PathVariable Integer id, @RequestBody Usuarios usu) {
        try {
            Usuarios usuario2 = usuariosService.buscarUsuariosporId(id);
            usuario2.setIdUsuario(id);
            usuario2.setRun(usu.getRun());
            usuario2.setNombres(usu.getNombres());
            usuario2.setApellidos(usu.getApellidos());
            usuario2.setCorreo(usu.getCorreo());
            usuario2.setTelefono(usu.getTelefono());

            usuariosService.saveUsuario(usuario2);
            return ResponseEntity.ok(usuario2);

        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}
