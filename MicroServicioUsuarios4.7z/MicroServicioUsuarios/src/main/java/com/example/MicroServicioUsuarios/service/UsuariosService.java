package com.example.MicroServicioUsuarios.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.MicroServicioUsuarios.model.Rol;
import com.example.MicroServicioUsuarios.model.Usuarios;
import com.example.MicroServicioUsuarios.repository.Rolerepository;
import com.example.MicroServicioUsuarios.repository.UsuariosRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class UsuariosService {

    @Autowired
    private Rolerepository rolerepository;

    @Autowired
    private UsuariosRepository usuariosRepository;

    @Autowired
    private BCryptPasswordEncoder passwordEncoder;

    // Obtener todos los usuarios
    public List<Usuarios> listarUsuarios() {
        return usuariosRepository.findAll();
    }

    // Obtener usuario por ID
    public Usuarios buscarUsuariosporId(Integer id){
        return usuariosRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado con ID: " + id));
    }

    // Guardar usuario validando el rol
   public Usuarios saveUsuario(Usuarios usuarios) {
    if (usuarios.getRol() != null && usuarios.getRol().getId() != null) {
        Rol rol = rolerepository.findById(usuarios.getRol().getId())
                .orElseThrow(() -> new RuntimeException("Rol no encontrado con ID: " + usuarios.getRol().getId()));
        usuarios.setRol(rol);
    } else {
        throw new RuntimeException("Debes proporcionar un ID de rol valido");
    }

    // Encriptar clave antes de guardar
    usuarios.setClave(passwordEncoder.encode(usuarios.getClave()));

    return usuariosRepository.save(usuarios);
}   
    // validar la clave encriptada
    public Optional<Usuarios> validarCredenciales(String correo, String claveIngresada) {
    Optional<Usuarios> optionalUsuario = usuariosRepository.findByCorreo(correo);

    if (optionalUsuario.isPresent()) {
        Usuarios usuario = optionalUsuario.get();
        if (passwordEncoder.matches(claveIngresada, usuario.getClave())) {
            return Optional.of(usuario);
        }
    }

    return Optional.empty();
}

       // Eliminar usuario por ID
    public void borrarUsuarios(Integer id){
        usuariosRepository.deleteById(id);
    }
    
public Usuarios crearUsuario(String user, String ape, String mail, String pass, Integer tel, Long idRol) {
    Rol role = rolerepository.findById(idRol)
            .orElseThrow(() -> new RuntimeException("Rol no existe con ID: " + idRol));

    Usuarios usuario1 = new Usuarios();
    usuario1.setNombres(user);
    usuario1.setApellidos(ape);
    usuario1.setCorreo(mail);
    usuario1.setClave(passwordEncoder.encode(pass)); // Encriptar clave
    usuario1.setTelefono(tel);
    usuario1.setRol(role);

    return usuariosRepository.save(usuario1);
 
}


}