package com.example.MicroServicioUsuarios.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.example.MicroServicioUsuarios.model.Rol;
import com.example.MicroServicioUsuarios.model.Usuarios;
import com.example.MicroServicioUsuarios.repository.Rolerepository;
import com.example.MicroServicioUsuarios.repository.UsuariosRepository;

import jakarta.transaction.Transactional;

//esta clase se encarga de cargar datos iniciales 
//unicamente si las tablas estene vacias


@Configuration
@Transactional
public class LoadDatabase {

  private final BCryptPasswordEncoder passwordEncoder;



    public LoadDatabase(BCryptPasswordEncoder passwordEncoder) {
        this.passwordEncoder = passwordEncoder;
    }
        
    @Bean
    CommandLineRunner initDatabase(Rolerepository roleRepo, UsuariosRepository userRepo) {
        return args -> {

            // Solo crea roles si no hay roles
            if (roleRepo.count() == 0) {
                Rol admin = new Rol();
                admin.setNombre("administrador");
                roleRepo.save(admin);

                Rol user = new Rol();
                user.setNombre("Usuario");
                roleRepo.save(user);

                Rol sup = new Rol();
                sup.setNombre("soporte"); 
                roleRepo.save(sup);

                Rol client = new Rol();
                client.setNombre("cliente"); 
                roleRepo.save(client);

                Rol invi = new Rol();
                invi.setNombre("invitado"); 
                roleRepo.save(invi);

                Rol plani = new Rol();
                plani.setNombre("planificador");
                roleRepo.save(plani);

                System.out.println("Roles iniciales cargados");
            } else {
                System.out.println("Roles ya existentes");
            }

            // Solo crea el usuario administrador si no hay usuarios
            if (userRepo.count() == 0) {
                Rol adminRole = roleRepo.findByNombre("administrador")
                    .orElseThrow(() -> new RuntimeException("No se encontró el rol administrador"));

                Usuarios adminUser = new Usuarios();
                adminUser.setRun("11.111.111-1");
                adminUser.setNombres("Admin");
                adminUser.setApellidos("Principal");
                adminUser.setCorreo("admin@.cl");
                adminUser.setClave(passwordEncoder.encode("admin123"));
                adminUser.setTelefono(123456789);
                adminUser.setRol(adminRole);

                userRepo.save(adminUser);

                System.out.println("Usuario administrador creado");
            } else {
                System.out.println("Usuarios ya existentes");
            }
        };
    }
}
