package com.example.MicroservicioEventos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicroservicioEventosApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicioEventosApplication.class, args);
	}

}
