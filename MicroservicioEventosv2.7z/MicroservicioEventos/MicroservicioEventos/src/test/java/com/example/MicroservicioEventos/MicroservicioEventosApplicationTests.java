package com.example.MicroservicioEventos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroservicioEventosApplicationTests {

	@Test
	void contextLoads() {
	}

}
