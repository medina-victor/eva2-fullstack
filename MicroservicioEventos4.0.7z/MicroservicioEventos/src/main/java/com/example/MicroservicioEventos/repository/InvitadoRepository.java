package com.example.MicroservicioEventos.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.MicroservicioEventos.model.Invitado;

public interface InvitadoRepository extends JpaRepository<Invitado,Long>{
List<Invitado> findByEvento_IdEvento(Long idEvento);


}
