package com.example.MicroservicioEventos.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.MicroservicioEventos.model.Eventos;
import com.example.MicroservicioEventos.repository.EventosRepository;
import com.example.MicroservicioEventos.service.EventoService;

@RestController
@RequestMapping("/api/v1/eventos")
public class EventosController {
    @Autowired
    private EventoService eventoService;

    @Autowired 
    private EventosRepository eventosRepository;

    //lsitar eventos
    @GetMapping
    public ResponseEntity<List<Eventos>> obtenerEventos(){
        List<Eventos> lista = eventoService.getEventos();
        if(lista.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(lista);
    }

    //crear evetno
    @PostMapping
    public ResponseEntity<?> crearEvento(@RequestBody Eventos nuevoEventos){
        try {
            Eventos eventos = eventoService.saveEventos(nuevoEventos);
            return ResponseEntity.status(201).body(eventos);
        } catch (Exception e) {
            return ResponseEntity.status(404).body(e.getMessage());
        }
    }
     @GetMapping("/{id}")
    public ResponseEntity<Eventos> obtenerEventoPorId(@PathVariable Long id) {
        return eventosRepository.findById(id)
                .map(evento -> ResponseEntity.ok(evento))
                .orElse(ResponseEntity.notFound().build());
    }
}
