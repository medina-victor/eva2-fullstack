package com.example.MicroservicioEventos.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.MicroservicioEventos.model.Invitado;
import com.example.MicroservicioEventos.service.InvitadoService;

@RestController
@RequestMapping("/api/v1/invitados")

public class InvitadosController {

    @Autowired
    private InvitadoService invitadoService;


    @PostMapping
    public ResponseEntity<Invitado> crearInvitado(@RequestBody Invitado invitado){
        Invitado nuevoInvitado = invitadoService.saveInvitado(invitado);
        return ResponseEntity.status(201).body(nuevoInvitado);
    }
      
  @GetMapping
    public ResponseEntity<List<Invitado>> ListaDeInvitados(){
        List<Invitado> invitados = invitadoService.ListaDeInvitados();
        if (invitados.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(invitados);
    }


    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarInvitado(@PathVariable Long id) {
        invitadoService.elimnarInvitado(id);
        return ResponseEntity.noContent().build();
    }


    //lista por id de evento
     @GetMapping("/evento/{idEvento}")
    public ResponseEntity<List<Invitado>> listarPorEvento(@PathVariable Long idEvento) {
        List<Invitado> invitados = invitadoService.ListaPorEvento(idEvento);
        if (invitados.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(invitados);
    }



}
