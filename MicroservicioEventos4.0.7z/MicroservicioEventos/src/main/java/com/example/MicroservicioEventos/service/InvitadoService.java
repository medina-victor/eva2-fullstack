package com.example.MicroservicioEventos.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.MicroservicioEventos.model.Invitado;
import com.example.MicroservicioEventos.repository.InvitadoRepository;

@Service

public class InvitadoService {

    @Autowired
    InvitadoRepository invitadoRepository;

    public List<Invitado> ListaDeInvitados(){
        return invitadoRepository.findAll();
    }

    public Invitado saveInvitado(Invitado invitado){
        return invitadoRepository.save(invitado);
    }
     public Optional<Invitado>buscarPorId(Long id){
        return invitadoRepository.findById(id);
    }

    public void elimnarInvitado(Long id){
         invitadoRepository.deleteById(id);
    }


  public List<Invitado> ListaPorEvento(Long idEvento){
    return invitadoRepository.findByEvento_IdEvento(idEvento);
}

}
