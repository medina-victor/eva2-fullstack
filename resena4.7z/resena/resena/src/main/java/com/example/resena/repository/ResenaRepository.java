package com.example.resena.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.resena.model.Resena;

public interface ResenaRepository extends JpaRepository <Resena,Long> {

    List<Resena> findByIdEvento(Long idEvento);
    List<Resena> findByIdUsuario(Integer idUsuario);
}
