package com.example.resena.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.resena.model.Resena;
import com.example.resena.repository.ResenaRepository;
import com.example.resena.service.ResenaService;

@RestController
@RequestMapping("/api/v1/resenas")

public class ResenaController {

    @Autowired
    ResenaRepository resenaRepository;

    @Autowired
    ResenaService resenaService;

    @GetMapping
    public List<Resena> listarTodas(){
        return resenaService.ObtenerResenas();
    }
    
    @PostMapping
    public ResponseEntity<Resena> crearResena(@RequestBody Resena resena){
        Resena nueva = resenaService.guardar(resena);
        return ResponseEntity.ok(nueva); 
    }
    @GetMapping("/evento/{idEvento}")
    public List<Resena> listarPorEvento(@PathVariable Long idEvento) {
        return resenaService.ObtenerPorEvento(idEvento);
    }

    @GetMapping("/usuario/{idUsuario}")
    public List<Resena> listarPorUsuario(@PathVariable Integer idUsuario) {
        return resenaService.ObtenerPorUsuario(idUsuario);
    }



}
