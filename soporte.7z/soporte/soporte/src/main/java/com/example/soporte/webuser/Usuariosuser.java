package com.example.soporte.webuser;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;

@Component

public class Usuariosuser {
     //varia cominicacion
    private final WebClient webClient;

    // constructor 

    public Usuariosuser(@Value("${Usuarios-service.url}")String usuarioServiceUrl){
        this.webClient = WebClient.builder().baseUrl(usuarioServiceUrl).build();
     }
    
    public Map<String,Object> getUsuarioById(Long id){
        return this.webClient.get()
        .uri("/{id}",id)
        .retrieve()
        .onStatus(status -> status.is4xxClientError(),
        response -> response.bodyToMono(String.class)
        .map(body -> new RuntimeException("usuario no en contrado")))
        .bodyToMono(Map.class).block();


    }


}
