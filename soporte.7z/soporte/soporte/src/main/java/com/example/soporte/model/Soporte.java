package com.example.soporte.model;

import java.sql.Date;

import jakarta.persistence.Column;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

public class Soporte {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name="IdSoporte")
    private Long IdSoporte;


    @Column(name="fechaCrticket")
    private Date FechaCrtickcet;

    @Column(name="tipoDeproblema")
    private String TipoDeProbla;

    @Column (name="idUsuario")
    private Integer idUsuario;

    @Column(name="soporteId")
    private Integer soporteId;



}
