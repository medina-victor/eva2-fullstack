package com.example.soporte.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.soporte.model.Soporte;
import com.example.soporte.repository.SoporteRepository;
import com.example.soporte.service.SoporteService;

@RestController
@RequestMapping("/api/v1/Soporte")
public class SoporteController {

    private final SoporteRepository soporteRepository;


    @Autowired
    private SoporteService soporteService;

    SoporteController(SoporteRepository soporteRepository) {
        this.soporteRepository = soporteRepository;
    }

    @PostMapping
    public Soporte crearSoporte(@RequestBody Soporte soporte) {
        return soporteService.guardarSoporte(soporte);
    }


    @GetMapping
    public ResponseEntity<List<Soporte>> listar() {
        List<Soporte> soporte = soporteService.listaSoporte();
        if (soporte.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(soporte);
    }


}
