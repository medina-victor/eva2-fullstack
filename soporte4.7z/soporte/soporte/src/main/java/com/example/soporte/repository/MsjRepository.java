package com.example.soporte.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.soporte.model.Msj;

public interface MsjRepository extends JpaRepository<Msj,Long>{
    List<Msj> findBySoporteIdTicket(Long soporteId);

}
