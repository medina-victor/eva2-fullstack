package com.example.soporte.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.soporte.model.Msj;
import com.example.soporte.model.Soporte;
import com.example.soporte.repository.MsjRepository;
import com.example.soporte.repository.SoporteRepository;

@Service

public class MsjService {

    @Autowired
    private MsjRepository msjRepository;

    @Autowired
    private SoporteRepository soporteRepository;

    public Msj guardarMensaje(Msj msj) {
        if (msj.getSoporte() != null && msj.getSoporte().getIdTicket() != null) {
            Soporte soporte = soporteRepository.findById(msj.getSoporte().getIdTicket())
                .orElseThrow(() -> new RuntimeException("Soporte no encontrado"));
            msj.setSoporte(soporte);
        } else {
            throw new RuntimeException("ID de Soporte no proporcionado");
        }

        return msjRepository.save(msj);
    }

    public List<Msj> listarMensajes() {
        return msjRepository.findAll();
    }
}