package com.example.soporte.model;

import java.time.LocalDate;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name = "soporte")


@Data
@AllArgsConstructor
@NoArgsConstructor


public class Soporte {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(nullable = true)
    private Long idTicket;

    @Column(nullable = true)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
    private LocalDate FechaCrticket;


    @Column(nullable = true)
    private String TipoDeProblema;

    @Column(nullable = true)
    private String Motivo;

    @Column (nullable = true)
    private Integer idUsuario;

    @Column(nullable = true)
    private Integer TecsoporteId;

    @OneToMany(mappedBy = "soporte", cascade = CascadeType.ALL)
    @JsonIgnore
    private List<Msj> mensajes;


}
