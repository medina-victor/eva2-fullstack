package com.example.MicroServicioUsuarios.config;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.example.MicroServicioUsuarios.model.Rol;
import com.example.MicroServicioUsuarios.model.Usuarios;
import com.example.MicroServicioUsuarios.repository.Rolerepository;
import com.example.MicroServicioUsuarios.repository.UsuariosRepository;

//esta clase se encarga de cargar datos iniciales 
//unicamente si las tablas estene vacias


@Configuration
public class LoadDatabase {
    @Bean
    CommandLineRunner initDatabase(Rolerepository roleRepo, UsuariosRepository userRepo) {
        return args -> {
            // Si las tablas están vacías - no hay registros
            if (roleRepo.count() == 0 && userRepo.count() == 0) {
                // Cargar los roles por defecto 
                Rol admin = new Rol();
                admin.setNombre("administrador");
                roleRepo.save(admin);

                Rol user = new Rol();
                user.setNombre("Usuario");
                roleRepo.save(user);

                Rol sup = new Rol();
                sup.setNombre("soporte"); 
                roleRepo.save(sup);

                Rol client = new Rol();
                client.setNombre("cliente"); 
                roleRepo.save(client);

                Rol invi = new Rol();
                invi.setNombre("invitado"); 
                roleRepo.save(invi);

                Rol plani = new Rol();
                plani.setNombre("planificador");
                roleRepo.save(plani);

                // Cargar usuarios por defecto o iniciales
                userRepo.save(new Usuarios(null, "21.451.213", "victor", "medina", "prueba@gmail.com", "contraseña", null, admin));

                System.out.println("Datos iniciales Cargados");
            } else {
                System.out.println("Datos ya existentes. No se cargaron nuevos datos");
            }
        };
    }
}
