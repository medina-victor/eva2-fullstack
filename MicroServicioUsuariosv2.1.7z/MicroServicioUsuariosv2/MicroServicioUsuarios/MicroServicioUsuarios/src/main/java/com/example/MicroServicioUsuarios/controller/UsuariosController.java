package com.example.MicroServicioUsuarios.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.MicroServicioUsuarios.model.Usuarios;
import com.example.MicroServicioUsuarios.repository.UsuariosRepository;
import com.example.MicroServicioUsuarios.service.UsuariosService;

@RestController
@RequestMapping("/api/v1/Usuarios")
@CrossOrigin(origins = "*") // Opcional para permitir llamadas desde Postman u otro servicio
public class UsuariosController {

    private final UsuariosRepository usuariosRepository;

    @Autowired
    private UsuariosService usuariosService;

    
    public UsuariosController(UsuariosRepository usuariosRepository) {
        this.usuariosRepository = usuariosRepository;
    }

    @PostMapping("/validar")
    public ResponseEntity<Usuarios> validar(@RequestBody Usuarios usuario) {
        return usuariosRepository.findByCorreoAndClave(usuario.getCorreo(), usuario.getClave())
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.status(HttpStatus.UNAUTHORIZED).build());
    }

    @GetMapping
    public ResponseEntity<List<Usuarios>> listar() {
        List<Usuarios> usuarios = usuariosService.listarUsuarios();
        if (usuarios.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(usuarios);
    }

    @PostMapping
    public ResponseEntity<Usuarios> guardarUsuarios(@RequestBody Usuarios usuarios) {
        Usuarios usu = usuariosService.saveUsuario(usuarios);
        return ResponseEntity.status(HttpStatus.CREATED).body(usu);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Usuarios> buscarUsuariosPorId(@PathVariable Integer id) {
        try {
            Usuarios usu = usuariosService.buscarUsuariosporId(id);
            return ResponseEntity.ok(usu);
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> borrarUsuariosPorId(@PathVariable Long id) {
        try {
            Usuarios usu = usuariosService.buscarUsuariosporId(id.intValue());
            usuariosService.borrarUsuarios(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<Usuarios> actualizarUsuariosPorid(@PathVariable Integer id, @RequestBody Usuarios usu) {
        try {
            Usuarios usuario2 = usuariosService.buscarUsuariosporId(id);
            usuario2.setIdUsuario(id);
            usuario2.setRun(usu.getRun());
            usuario2.setNombres(usu.getNombres());
            usuario2.setApellidos(usu.getApellidos());
            usuario2.setCorreo(usu.getCorreo());
            usuario2.setTelefono(usu.getTelefono());

            usuariosService.saveUsuario(usuario2);
            return ResponseEntity.ok(usuario2);

        } catch (Exception e) {
            return ResponseEntity.notFound().build();
        }
    }
}
