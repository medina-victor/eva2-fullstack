package com.example.MicroServicioUsuarios.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;




@Entity
@Table(name="Usuarios")

@Data
@AllArgsConstructor
@NoArgsConstructor

public class Usuarios {


@Id
@GeneratedValue(strategy = GenerationType.IDENTITY) //indico que el campo se genera automáticamente
    private Integer idUsuario;

    

    @Column(unique = true, length = 12, nullable = false) //definir las restricciones del campo
    private String run;


    @Column(nullable = false, length = 100)
    private String nombres;

    @Column(nullable = false,length = 50)
    private String apellidos;

    @Column(nullable = true,length = 25)
    private String correo;

    @Column(nullable = false,length = 18)
    private String clave;
    
    @Column(nullable = false, length = 9 )
    private Integer telefono;


    @ManyToOne
    @JoinColumn(name = "rol_id")
    @JsonIgnoreProperties
    private Rol rol;

    

}






