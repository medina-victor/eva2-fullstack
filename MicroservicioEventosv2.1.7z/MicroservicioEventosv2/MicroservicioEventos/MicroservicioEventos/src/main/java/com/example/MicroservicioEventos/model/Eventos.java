package com.example.MicroservicioEventos.model;
import jakarta.persistence.GenerationType;

import java.util.Date;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "eventos")
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Eventos {


    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id_evento;

    @Column(nullable = false ,length = 30)
    private String nom_evento;

    @Column(nullable = false)
    private Date fecha_creacionev;
    
    @Column(nullable = false)
    private String estado;

    @Column(nullable = false)
    private Integer presupuesto;

    @Column(nullable = true)
    private Date fecha_eve;

    @Column(nullable = true)
    private Date fe_asigpla;

    @Column
    private Long usuarioId;

    @Column
    private Long planificadorId;

}
