package com.example.MicroservicioEventos.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.MicroservicioEventos.model.Eventos;
import com.example.MicroservicioEventos.repository.EventosRepository;
import com.example.MicroservicioEventos.webuser.Usuariosuser;

import jakarta.transaction.Transactional;

@Service
@Transactional

public class EventoService {

    @Autowired
    private EventosRepository eventosRepository;
    @Autowired 
    private Usuariosuser usuariosuser;

    //metodo para traer toods los eventos 
    public List<Eventos> getEventos(){
        return eventosRepository.findAll();
    }


    //nuevo evento 

    public Eventos saveEventos(Eventos nuevoEvento){

        Map<String,Object> Usuarios= usuariosuser.getUsuarioById(nuevoEvento.getUsuarioId());

        if (Usuarios == null || Usuarios.isEmpty()){
            throw new RuntimeException("usuario no encontrado no se puede hacer el evento");
        }
             
   
            return eventosRepository.save(nuevoEvento);
    }
}
