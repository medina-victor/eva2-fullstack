package com.example.Presupuesto.Model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Table(name="presupuesto")

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Presupuesto {
    @Id 
    @GeneratedValue ( strategy = GenerationType.IDENTITY)
    
    private Long idPresupuesto;

    @Column(nullable = false)
    private String descripcion;
    
    @Column(nullable = false)
    private Integer MontoMaximo;

    @Column(nullable = false)
    private Integer Tarea1;

    @Column(nullable = true)
    private Integer Tarea2;

    @Column
    private Integer Tarea3;

    @Column
    private String estado;

    @Column
    private Integer Costo;

    @Column
    private Long IdEvento;

}
