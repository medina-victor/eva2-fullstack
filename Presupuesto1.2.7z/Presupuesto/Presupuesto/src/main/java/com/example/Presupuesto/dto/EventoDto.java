package com.example.Presupuesto.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class EventoDto {

    @JsonProperty("id_evento")
    private Long idEvento;
    
    private Integer presupuesto;

 
}


