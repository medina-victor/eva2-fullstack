package com.example.Presupuesto.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.example.Presupuesto.Model.Presupuesto;
import com.example.Presupuesto.Repository.PresupuestoRepository;
import com.example.Presupuesto.dto.EventoDto;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class PresupuestoService {

    @Autowired
    private PresupuestoRepository presupuestoRepository;

    @Autowired
    private RestTemplate restTemplate;

   public Presupuesto guardarPresupuesto(Presupuesto presupuesto) {
    if (presupuesto.getIdEvento() == null) {
        throw new IllegalArgumentException("El idEvento es obligatorio para obtener el presupuesto.");
    }

    String url = "http://localhost:8089/api/v1/eventos/" + presupuesto.getIdEvento();
    EventoDto evento = restTemplate.getForObject(url, EventoDto.class);

    if (evento == null || evento.getPresupuesto() == null) {
        throw new IllegalArgumentException("No se encontró el evento o no tiene presupuesto asignado.");
    }

    int montoMaximo = evento.getPresupuesto();
    presupuesto.setMontoMaximo(montoMaximo);

    int tarea1 = presupuesto.getTarea1() != null ? presupuesto.getTarea1() : 0;
    int tarea2 = presupuesto.getTarea2() != null ? presupuesto.getTarea2() : 0;
    int tarea3 = presupuesto.getTarea3() != null ? presupuesto.getTarea3() : 0;

    int sumaTareas = tarea1 + tarea2 + tarea3;

    if (sumaTareas > montoMaximo) {
        throw new IllegalArgumentException("La suma de las tareas no puede superar el presupuesto del evento.");
    }

    presupuesto.setCosto(sumaTareas);

    return presupuestoRepository.save(presupuesto);
}

    public List<Presupuesto> listaPresupuestos(){
        return presupuestoRepository.findAll();
    }
}




