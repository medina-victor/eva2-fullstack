package com.example.Presupuesto.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.Presupuesto.Model.Presupuesto;
import com.example.Presupuesto.Service.PresupuestoService;

@RestController
@RequestMapping("/api/v1/presupuestos")
public class PresupuestoController {
        @Autowired
    private PresupuestoService presupuestoService;

    @PostMapping
    public ResponseEntity<?> crearPresupuesto(@RequestBody Presupuesto presupuesto) {
        try {
            Presupuesto nuevo = presupuestoService.guardarPresupuesto(presupuesto);
            return ResponseEntity.ok(nuevo);
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

       @GetMapping
    public ResponseEntity<List<Presupuesto>> listar() {
        List<Presupuesto> presupuesto = presupuestoService.listaPresupuestos();
        if (presupuesto.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(presupuesto);
    }

}
