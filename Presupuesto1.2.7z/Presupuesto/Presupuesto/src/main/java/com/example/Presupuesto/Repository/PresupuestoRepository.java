package com.example.Presupuesto.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Presupuesto.Model.Presupuesto;

public interface PresupuestoRepository extends JpaRepository<Presupuesto,Long>{

}
