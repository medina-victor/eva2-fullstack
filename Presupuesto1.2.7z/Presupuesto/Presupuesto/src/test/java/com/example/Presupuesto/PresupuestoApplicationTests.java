package com.example.Presupuesto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PresupuestoApplicationTests {

	@Test
	void contextLoads() {
	}

}
