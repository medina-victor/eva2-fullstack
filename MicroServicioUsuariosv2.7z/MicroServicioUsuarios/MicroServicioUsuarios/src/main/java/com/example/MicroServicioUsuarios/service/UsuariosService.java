package com.example.MicroServicioUsuarios.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.MicroServicioUsuarios.model.Rol;
import com.example.MicroServicioUsuarios.model.Usuarios;
import com.example.MicroServicioUsuarios.repository.Rolerepository;
import com.example.MicroServicioUsuarios.repository.UsuariosRepository;

import jakarta.transaction.Transactional;

@Service
@Transactional

public class UsuariosService {

    @Autowired
    private Rolerepository rolerepository;

    @Autowired
    private  UsuariosRepository usuariosRepository;
    



        //funcion para obtener todos los pacientes
        public List<Usuarios> listarUsuarios(){
            return usuariosRepository.findAll();
        }

    
    //funcion para obtener un usuario x su id
    public Usuarios buscarUsuariosporId(long id){
        return usuariosRepository.findById(id).get();
    }

    //funcion para guardar un usuario
    public Usuarios saveUsuario(Usuarios usuarios){
        return usuariosRepository.save(usuarios);
    }

    //funcion para eliminar un usuario
    public void borrarUsuarios(long id){
        usuariosRepository.deleteById(id);
    }


    //metodo para agregar nuevo usuario
    public Usuarios crearUsuario(String user,String ape,String mail,String pass,Integer tel, Long idRol){
        Rol role = rolerepository.findById(idRol)
        .orElseThrow(()-> new RuntimeException("Rol no existe con ID:"+ idRol));

        Usuarios usuario1 = new Usuarios();
        usuario1.setNombres(user);
        usuario1.setApellidos(ape);
        usuario1.setCorreo(mail);
        usuario1.setClave(pass);
        usuario1.setTelefono(tel);
        usuario1.setRol(role);
        
        return usuariosRepository.save(usuario1);

        
    }
}
