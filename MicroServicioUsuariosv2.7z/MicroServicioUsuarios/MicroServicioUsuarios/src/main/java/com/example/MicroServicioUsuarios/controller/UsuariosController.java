package com.example.MicroServicioUsuarios.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.MicroServicioUsuarios.model.Usuarios;
import com.example.MicroServicioUsuarios.service.UsuariosService;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
@RequestMapping("/api/v1/Usuarios")

public class UsuariosController {
    

    @Autowired
    private UsuariosService usuariosService;

    //obtener todos los usuarios
    @GetMapping
    public ResponseEntity<List<Usuarios>> listar(){
        //guardar en una lista nueva los elementos
        List<Usuarios> usuarios = usuariosService.listarUsuarios();
        if(usuarios.isEmpty()){
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(usuarios);
    }
    
    //metodo para guardar un usuario
    @PostMapping
    public ResponseEntity<Usuarios> guardarUsuarios(@RequestBody Usuarios usuarios){
        //creamos un objeto nuevo
        Usuarios usu= usuariosService.saveUsuario(usuarios);
        return ResponseEntity.status(HttpStatus.CREATED).body(usu);
    }



     //metodo para buscar un usuario x id
    @GetMapping("/{id}")
    public ResponseEntity<Usuarios> buscarUsuariosPorId(@PathVariable Integer id){
        try {
            //verificar si el usuario existe
            Usuarios usu = usuariosService.buscarUsuariosporId(id);
            return ResponseEntity.ok(usu);
        } catch (Exception e) {
            //si no lo encuentra envio codigo not found
            return ResponseEntity.notFound().build();
        }
    }


    //metodo para eliminar un usuario por su id
    @DeleteMapping("/{id}")
    public ResponseEntity<?> borrarUsuariosPorId(@PathVariable Long id){
        try {
            //verificar si el usuario pexiste
            Usuarios usu = usuariosService.buscarUsuariosporId(id);
            usuariosService.borrarUsuarios(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            // no existe el usuario
            return ResponseEntity.notFound().build();
        }

    }

    //metodo para actualizar un usuario por su id
    @PutMapping("/{id}")
    public ResponseEntity<Usuarios> actualizarUsuariosPorid(@PathVariable Integer id, @RequestBody Usuarios usu){
        try {
            //verifico que el paciente existe
            Usuarios usuario2 = usuariosService.buscarUsuariosporId(id);
            //si existe modifico uno a uno sus valores
            usuario2.setIdUsuario(id);
            usuario2.setRun(usu.getRun());
            usuario2.setNombres(usu.getNombres());
            usuario2.setApellidos(usu.getApellidos());
            usuario2.setCorreo(usu.getCorreo());
            usuario2.setTelefono(usu.getTelefono());


            
            //actualizar el registro
            usuariosService.saveUsuario(usuario2);
            return ResponseEntity.ok(usuario2);

        } catch (Exception e) {
            // si no encuentra el usuario
            return ResponseEntity.notFound().build();
        }

    }


}
